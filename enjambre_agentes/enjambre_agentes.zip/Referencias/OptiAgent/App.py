import streamlit as st
import uuid
from pathlib import Path

# Cargar variables de entorno modulares
from my_keys import GEMINI_API_KEY, TAVILY_API_KEY

if not GEMINI_API_KEY or not TAVILY_API_KEY:
    st.error("Error: Faltan claves de API en el archivo .env. Asegúrate de configurar GEMINI_API_KEY y TAVILY_API_KEY.")
    st.stop()

# Importar funciones de LangGraph y RAG (ahora modularizados)
try:
    from rag_core import build_vectorstore
    from agentes import run_optiagent_stream
    from notificador_email import enviar_reporte_email
    from my_models import EMBEDDING_MODELS_INFO, get_available_llm_models
except Exception as e:
    st.error(f"Error al importar módulos de agentes o RAG: {e}")
    st.stop()

# --- CONFIGURACIÓN DE LA PÁGINA ---
st.set_page_config(
    page_title="OptiAgent-RAG | Multiagente Óptico",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- ESTADO DE SESIÓN ---
if "vectorstore_ready" not in st.session_state:
    st.session_state.vectorstore_ready = False
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "thread_id" not in st.session_state:
    # Generamos un ID de hilo único para la memoria persistente de LangGraph
    st.session_state.thread_id = str(uuid.uuid4())

# --- FUNCIONES ---
@st.cache_resource
def get_or_create_vectorstore(provider: str, force_rebuild: bool = False, db_type: str = "FAISS", model_name: str = None):
    """Obtiene el índice desde disco/nube o lo construye si no existe."""
    return build_vectorstore("data_pdf", provider=provider, force_rebuild=force_rebuild, db_type=db_type, model_name=model_name)

def manejar_indice(provider: str, db_type: str, force_rebuild: bool = False, model_name: str = None):
    st.session_state.vectorstore_ready = False
    action = "Reconstruyendo" if force_rebuild else "Cargando/Construyendo"
    with st.spinner(f"{action} índice vectorial ({db_type}) para {provider}..."):
        if force_rebuild:
            get_or_create_vectorstore.clear()
        try:
            retriever = get_or_create_vectorstore(provider, force_rebuild=force_rebuild, db_type=db_type, model_name=model_name)
            if retriever is not None:
                st.session_state.vectorstore_ready = True
                st.success(f"Índice de {provider} en {db_type} cargado con éxito.")
            else:
                st.warning("No se encontraron documentos para indexar.")
        except Exception as e:
            st.error(f"Error al construir el índice: {str(e)}")
            st.session_state.vectorstore_ready = False

# --- SIDEBAR ---
with st.sidebar:
    st.title("🔬 OptiAgent-RAG")
    st.markdown("Sistema Multiagente para Investigación en Óptica")
    
    st.header("Arquitectura Multiagente")
    flow_type = st.radio("🛣️ Modo de Investigación", ["Híbrido", "Solo Local", "Solo Web"])
    response_mode = st.radio("Estilo de Redacción", ["Modo Resumen", "Modo Científico"])
    st.markdown("""
    **Nodos disponibles:**
    1. **Agente A**: Analizador RAG (PDFs locales)
    2. **Agente B**: Búsqueda Web Académica (Tavily)
    3. **Agente C**: Síntesis y referencias cruzadas
    4. **Agente D**: Redactor Experto (Markdown)
    """)
    
    with st.expander("👁️ Ver Grafo de Ejecución (Mermaid)"):
        try:
            from agentes import opti_graph
            # Genera dinámicamente el PNG del StateGraph
            image_bytes = opti_graph.get_graph().draw_mermaid_png()
            st.image(image_bytes, caption="Flujo Multiagente en LangGraph")
        except Exception as e:
            st.warning("No se pudo renderizar el gráfico. Requiere conexión a internet para la API de Mermaid.")

    st.divider()

    st.header("Estado del Sistema")
    selected_model = st.selectbox("🧠 Proveedor LLM", ["Gemini", "Groq", "Cohere"])
    
    # Nuevo selector dinámico para el modelo LLM específico
    llm_variants = get_available_llm_models(selected_model)
    selected_llm_variant = st.selectbox("⚙️ Variante LLM", llm_variants)
    
    if flow_type != "Solo Web":
        selected_embedding = st.selectbox("📚 Motor de Embeddings", ["Gemini", "HuggingFace"])
        
        # Nuevo selector dinámico para el modelo específico de embedding
        model_options = list(EMBEDDING_MODELS_INFO[selected_embedding].keys())
        selected_model_name = st.selectbox("⚙️ Variante del Modelo", model_options)
        
        selected_db = st.selectbox("💾 Base de Datos Vectorial", ["FAISS", "Pinecone"])
    
    # ID de Memoria para fines de depuración/UX
    st.caption(f"🧵 ID Sesión (Memoria): `{st.session_state.thread_id[:8]}`")
    
    if flow_type != "Solo Web":
        st.subheader("Base Documental Local / Nube")
        if not st.session_state.vectorstore_ready:
            st.warning(f"Índice de {selected_embedding} en {selected_db} inactivo")
            if st.button("Cargar / Construir Índice", type="primary"):
                manejar_indice(selected_embedding, selected_db, force_rebuild=False, model_name=selected_model_name)
        else:
            st.success(f"Índice activo: {selected_embedding} ({selected_db})")
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 Cambiar Motor/DB"):
                    manejar_indice(selected_embedding, selected_db, force_rebuild=False, model_name=selected_model_name)
            with col2:
                if st.button("⚠️ Forzar Re-lectura"):
                    manejar_indice(selected_embedding, selected_db, force_rebuild=True, model_name=selected_model_name)
            
        st.divider()
    


# --- MAIN ÁREA ---
st.title("Asistente de Investigación Óptica")
st.markdown("Haz una pregunta científica relacionada con óptica. El sistema cruzará datos locales y búsquedas web, **recordando el contexto** de nuestra charla.")

if flow_type != "Solo Web" and not st.session_state.vectorstore_ready:
    st.info("👈 Por favor, construye el índice vectorial en el menú lateral para usar documentos locales.")
else:
    # Mostrar historial de forma simplificada en UI
    for i, msg in enumerate(st.session_state.chat_history):
        if msg["role"] == "user":
            with st.chat_message("user"):
                st.markdown(msg["content"])
        else:
            with st.chat_message("assistant"):
                st.markdown(msg["final_report"])
                
                with st.expander("📚 Fuentes Consultadas", expanded=False):
                    st.markdown("#### Documentos Locales (PDFs)")
                    if msg.get("local_src"):
                        for src in msg["local_src"]:
                            st.markdown(f"- {src}")
                    else:
                        st.write("No se utilizaron fuentes locales.")
                        
                    st.markdown("#### Fuentes Web / Patentes / arXiv")
                    if msg.get("web_src"):
                        for src in msg["web_src"]:
                            st.markdown(f"- {src}")
                    else:
                        st.write("No se utilizaron fuentes web.")
                        
                with st.expander("📧 Compartir este Reporte por Email"):
                    destinatario = st.text_input("Correo del destinatario (ej. colega@universidad.edu):", key=f"email_{i}")
                    if st.button("Enviar Reporte", key=f"btn_{i}"):
                        if destinatario:
                            with st.spinner("Enviando correo vía SMTP..."):
                                # Construir el contenido completo para el correo
                                full_content = msg["final_report"] + "\n\n### Fuentes Consultadas\n"
                                if msg.get("local_src"):
                                    full_content += "**Locales:**\n" + "\n".join([f"- {s}" for s in msg["local_src"]]) + "\n"
                                if msg.get("web_src"):
                                    full_content += "**Web:**\n" + "\n".join([f"- {s}" for s in msg["web_src"]]) + "\n"
                                    
                                exito = enviar_reporte_email(destinatario, "Reporte Científico de OptiAgent", full_content)
                            if exito:
                                st.success("¡Correo enviado exitosamente!")
                            else:
                                st.error("Falló el envío. Verifica tus credenciales.")
                        else:
                            st.warning("Por favor, ingresa un correo electrónico.")

    # Entrada del usuario
    query = st.chat_input("Ej: ¿Cuál es el impacto de la aberración esférica en telescopios reflectores?")
    
    if query:
        # Añadir al historial de la UI (El historial del LLM lo maneja MemorySaver internamente)
        st.session_state.chat_history.append({"role": "user", "content": query})
        with st.chat_message("user"):
            st.markdown(query)
            
        with st.chat_message("assistant"):
            st.markdown("### Procesando consulta...")
            status_container = st.container()
            report_placeholder = st.empty()
            sources_placeholder = st.empty()
            
            final_report = ""
            local_src = []
            web_src = []
            
            # Ejecutar el stream
            with status_container:
                with st.spinner(f"Iniciando orquestación LangGraph con {selected_model}..."):
                    # Pasamos el thread_id a run_optiagent_stream para activar el historial real del Agente
                    stream_generator = run_optiagent_stream(
                        query, 
                        thread_id=st.session_state.thread_id, 
                        provider=selected_model,
                        llm_model_name=selected_llm_variant,
                        flow_type=flow_type,
                        response_mode=response_mode
                    )
                    
                    for event in stream_generator:
                        for node_name, state_data in event.items():
                            if node_name == "rag_analyzer":
                                st.write("✅ **Agente A**: Recuperados documentos de PDFs locales")
                                local_src = state_data.get("sources_local", [])
                            elif node_name == "web_parser":
                                st.write("✅ **Agente B**: Búsqueda web paralela (Tavily/Academic/Scraper) completada")
                                web_src = state_data.get("sources_web", [])
                            elif node_name == "fusion":
                                st.write("✅ **Agente C**: Fusión de conocimiento y resolución de conflictos terminada")
                            elif node_name == "summary_writer":
                                st.write("✅ **Agente D1**: Redactando resumen ultra-corto")
                                final_report = state_data.get("final_report", "")
                            elif node_name == "scientific_writer":
                                st.write("✅ **Agente D2**: Redactando artículo científico estructurado")
                                final_report = state_data.get("final_report", "")
            
            # Mostrar resultado
            report_placeholder.markdown(final_report)
            
            # Mostrar fuentes
            with sources_placeholder.expander("📚 Fuentes Consultadas", expanded=False):
                st.markdown("#### Documentos Locales (PDFs)")
                if local_src:
                    for src in local_src:
                        st.markdown(f"- {src}")
                else:
                    st.write("No se utilizaron fuentes locales.")
                    
                st.markdown("#### Fuentes Web / Patentes / arXiv")
                if web_src:
                    for src in web_src:
                        st.markdown(f"- {src}")
                else:
                    st.write("No se utilizaron fuentes web.")
            
            # Guardar en historial de UI usando la nueva estructura
            st.session_state.chat_history.append({
                "role": "assistant", 
                "final_report": final_report,
                "local_src": local_src,
                "web_src": web_src
            })
            
            st.rerun()
