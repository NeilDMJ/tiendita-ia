# OptiAgent-RAG: Sistema Multiagente Inteligente para Investigación en Óptica

## Contexto

Construir un sistema multiagente orquestado con LangGraph que actúe como asistente especializado en **Óptica**, capaz de:
- Procesar PDFs científicos en inglés y español mediante RAG (FAISS + chunking inteligente)
- Buscar información académica en tiempo real (Tavily)
- Fusionar fuentes locales y externas con referencias cruzadas
- Generar reportes técnicos rigurosos en Markdown

La carpeta [OptiAgent](file:///home/m4r10/Documents/alura_AI/OptiAgent) ya contiene **5 PDFs científicos** de óptica (~265 MB total):
- `Óptica (Spanish Edition) (Eugene Hecht)` — Tratado completo (187 MB)
- `Optical Shop Testing 2do Edition` — Testing óptico (69 MB)
- `Óptica_Básica-Malacara.pdf` — Fundamentos (7.6 MB)
- Dos PDFs adicionales de investigación

> [!IMPORTANT]
> **Stack 100% Cloud-Native:** Groq (Llama 3 70B) + Gemini API. Sin Ollama ni ejecución local de modelos. FAISS se ejecuta en memoria durante el runtime.

---

## Propuestas de Diseño que Requieren tu Aprobación

> [!IMPORTANT]
> ### Decisión 1: Modelos LLM
> El blueprint menciona **Groq con Llama 3 70B** y **Gemini API**. Propongo:
> - **Agente principal (Fusionador + Redactor):** `gemini-2.5-flash` vía `langchain-google-genai` (el patrón que ya dominas de tus proyectos)
> - **Agente RAG + Búsqueda:** `gemini-2.5-flash` (mismo modelo, distintos prompts especializados)
> - **Embeddings:** `models/gemini-embedding-001` (mismo que usas en [1rag.py](file:///home/m4r10/Documents/alura_AI/2242-langchain-tecnicas-avanzadas-de-rag/1rag.py))
> - **Groq/Llama 3 70B:** Se integra como opción alternativa configurable vía `.env`
>
> ¿Quieres mantener Gemini como LLM primario, o prefieres que Groq/Llama sea el modelo principal?

> [!IMPORTANT]
> ### Decisión 2: Interfaz — Streamlit vs Gradio
> Tu blueprint pide **Streamlit**, pero todos tus proyectos previos usan **Gradio** (ver [24gradio.py](file:///home/m4r10/Documents/alura_AI/LangGraph-Agentes-Orquestacion/24gradio.py)). Yo seguiré Streamlit tal como indica el blueprint. ¿Correcto?

> [!IMPORTANT]
> ### Decisión 3: PDFs grandes (Eugene Hecht = 187 MB)
> El PDF de Hecht es enorme. Propongo **chunking selectivo**: procesar solo los primeros N capítulos o limitar a los primeros 200 páginas para el prototipo (configurable). En producción, se indexaría completo. ¿De acuerdo?

---

## Open Questions

> [!WARNING]
> ### API Keys requeridas
> El sistema necesitará las siguientes keys en el archivo `.env`:
> - `GEMINI_API_KEY` — para embeddings y LLM Gemini
> - `TAVILY_API_KEY` — para búsqueda web científica
> - `GROQ_API_KEY` — (opcional) para modelo alternativo Llama 3 70B
>
> ¿Ya las tienes disponibles o necesitas ayuda para obtener alguna?

---

## Proposed Changes

El desarrollo se estructura en **3 fases** alineadas con tu blueprint, con 6 archivos principales.

---

### Fase 1: Fundación RAG + Ingesta de PDFs

#### [NEW] [agentes.py](file:///home/m4r10/Documents/alura_AI/OptiAgent/agentes.py)
Módulo central que contiene los 4 agentes, el estado compartido, la vectorstore y el grafo LangGraph.

**Sección 1 — Configuración y Estado Compartido:**
```python
class OptiAgentState(TypedDict):
    query: str                    # Pregunta del usuario
    rag_context: str              # Contexto extraído de PDFs locales (Agente A)
    web_context: str              # Resultados de búsqueda web (Agente B)
    fused_context: str            # Contexto unificado con referencias cruzadas (Agente C)
    final_report: str             # Reporte final en Markdown (Agente D)
    sources_local: List[str]      # Referencias documentales locales
    sources_web: List[str]        # URLs y metadatos de fuentes web
```

**Sección 2 — Agente A: Analizador PDF (RAG Local):**
- Inspirado en el patrón de [1rag.py](file:///home/m4r10/Documents/alura_AI/2242-langchain-tecnicas-avanzadas-de-rag/1rag.py) y [ragchain_local.py](file:///home/m4r10/Documents/alura_AI/2242-langchain-tecnicas-avanzadas-de-rag/ragchain_local.py)
- `PyPDFLoader` + `DirectoryLoader` para cargar todos los PDFs de `data_pdf/`
- `RecursiveCharacterTextSplitter` (chunk_size=1500, overlap=300) — valores mayores que los de referencia porque los textos científicos tienen párrafos largos
- `GoogleGenerativeAIEmbeddings` con `gemini-embedding-001`
- `FAISS.from_documents()` para vectorstore en memoria (patrón de [ragchain_local.py L71](file:///home/m4r10/Documents/alura_AI/2242-langchain-tecnicas-avanzadas-de-rag/ragchain_local.py#L71))
- Retriever con `k=4` (más fragmentos para rigor científico)
- Función nodo: `rag_analyzer_node(state)` → escribe en `rag_context` y `sources_local`

**Sección 3 — Agente B: Búsqueda Web Científica (Tavily):**
- Inspirado en [20orquestado_multiagente.py L88-L100](file:///home/m4r10/Documents/alura_AI/LangGraph-Agentes-Orquestacion/20orquestado_multiagente.py#L88-L100)
- Usa `model.with_structured_output(SearchQueries)` para generar queries de búsqueda óptimas
- `TavilySearch(max_results=3)` enfocado en fuentes académicas
- El prompt del sistema instruye al LLM a formular queries en inglés científico (para obtener mejores resultados en Tavily) incluyendo términos como "optics", "lens", "refraction", etc.
- Función nodo: `web_search_node(state)` → escribe en `web_context` y `sources_web`

**Sección 4 — Agente C: Fusionador (Synthesis Agent):**
- Patrón nuevo inspirado en el `supervisor_node` de [7nodo_supervisado.py L107-L134](file:///home/m4r10/Documents/alura_AI/2217-Agentes-de-IA-con-LangGraph/7nodo_supervisado.py#L107-L134)
- Recibe `rag_context` y `web_context` del estado
- Prompt especializado que instruye a:
  1. Identificar complementariedades (lo que una fuente tiene y la otra no)
  2. Detectar divergencias teóricas
  3. Unificar terminología (inglés ↔ español)
  4. Generar un bloque de "contexto fusionado" con etiquetas de procedencia `[LOCAL]` / `[WEB]`
- Función nodo: `fusion_node(state)` → escribe en `fused_context`

**Sección 5 — Agente D: Redactor Experto:**
- Inspirado en el `generation_node` de [20orquestado_multiagente.py L103-L118](file:///home/m4r10/Documents/alura_AI/LangGraph-Agentes-Orquestacion/20orquestado_multiagente.py#L103-L118)
- Toma `fused_context`, `sources_local` y `sources_web`
- Prompt de sistema que establece:
  - Redacción en español técnico riguroso
  - Formato Markdown estructurado (título, resumen, desarrollo, conclusión, referencias)
  - Citación de fuentes con formato `[Fuente: nombre_pdf, pág. X]` y `[Web: URL]`
- Función nodo: `report_writer_node(state)` → escribe en `final_report`

**Sección 6 — Ensamblaje del Grafo LangGraph:**
```
Flujo lineal:  START → rag_analyzer → web_search → fusion → report_writer → END
```
- Compilación con `StateGraph(OptiAgentState)`
- Patrón de [23muitiagentes_grafo.py L166-L187](file:///home/m4r10/Documents/alura_AI/LangGraph-Agentes-Orquestacion/23muitiagentes_grafo.py#L166-L187)
- Sin checkpointer para simplificar (se agrega en Fase 3 si es necesario)

**Función auxiliar exportada:**
- `build_vectorstore(pdf_directory: str) -> retriever` — construye el índice FAISS. Se invoca una sola vez al iniciar la app.
- `run_optiagent(query: str) -> dict` — ejecuta el grafo completo y devuelve el estado final.

---

#### [NEW] [data_pdf/](file:///home/m4r10/Documents/alura_AI/OptiAgent/data_pdf/)
Directorio dedicado para los PDFs científicos. Los 5 PDFs actuales se **moverán** aquí desde la raíz del proyecto.

#### [NEW] [vectorstore/](file:///home/m4r10/Documents/alura_AI/OptiAgent/vectorstore/)
Directorio para almacenar opcionalmente los índices FAISS serializados (`.faiss` + `.pkl`). En el prototipo, FAISS se construye en memoria; en producción, se persiste aquí.

#### [NEW] [.env](file:///home/m4r10/Documents/alura_AI/OptiAgent/.env)
```env
GEMINI_API_KEY=tu_key_aqui
TAVILY_API_KEY=tu_key_aqui
GROQ_API_KEY=tu_key_aqui_opcional
```

#### [NEW] [.gitignore](file:///home/m4r10/Documents/alura_AI/OptiAgent/.gitignore)
```
.env
venv/
__pycache__/
vectorstore/*.faiss
vectorstore/*.pkl
data_pdf/
*.db
```

---

### Fase 2: Interfaz Streamlit Interactiva

#### [NEW] [App.py](file:///home/m4r10/Documents/alura_AI/OptiAgent/App.py)
Interfaz web interactiva con Streamlit.

**Componentes de la UI:**
1. **Sidebar:**
   - Estado del sistema (PDFs cargados, chunks generados, modelo activo)
   - Botón "🔄 Reconstruir Índice" para re-indexar PDFs
   - Indicador visual de las fases del pipeline (RAG → Web → Fusión → Reporte)

2. **Panel Principal:**
   - Campo de texto para la pregunta del usuario
   - Botón "🔬 Investigar" que dispara el grafo
   - Área de salida con formato Markdown renderizado
   - Sección colapsable "📚 Fuentes y Referencias" con las citas detalladas

3. **Flujo de Ejecución:**
   - Al presionar "Investigar", se ejecuta `run_optiagent(query)` de `agentes.py`
   - Se usa `st.status()` para mostrar progreso en tiempo real de cada agente
   - El reporte final se renderiza con `st.markdown()`

**Patrón de referencia:** Adaptación del flujo de streaming de [24gradio.py L190-L220](file:///home/m4r10/Documents/alura_AI/LangGraph-Agentes-Orquestacion/24gradio.py#L190-L220), portado a los componentes nativos de Streamlit.

---

### Fase 3: Documentación y Preparación para Deploy

#### [NEW] [requirements.txt](file:///home/m4r10/Documents/alura_AI/OptiAgent/requirements.txt)
```
langchain
langchain-google-genai
langchain-community
langchain-tavily
langgraph
python-dotenv
faiss-cpu
pypdf
streamlit
tavily-python
pydantic
```

#### [NEW] [README.md](file:///home/m4r10/Documents/alura_AI/OptiAgent/README.md)
Documentación completa con:
1. Descripción de la arquitectura multiagente y diagrama de flujo (Mermaid)
2. Guía de instalación y ejecución local paso a paso
3. Ejemplos de preguntas y respuestas científicas de óptica
4. Placeholder para evidencia de despliegue en la nube (OCI / Streamlit Cloud)

---

## Diagrama de Arquitectura del Grafo

```mermaid
graph LR
    START((🟢 START)) --> A["🔍 Agente A<br/>RAG Analyzer<br/>(FAISS + PDFs)"]
    A --> B["🌐 Agente B<br/>Web Search<br/>(Tavily API)"]
    B --> C["🔗 Agente C<br/>Fusionador<br/>(Cross-Reference)"]
    C --> D["📝 Agente D<br/>Redactor Experto<br/>(Report Writer)"]
    D --> END_NODE((🔴 END))

    subgraph Estado Compartido
        S1["query"]
        S2["rag_context + sources_local"]
        S3["web_context + sources_web"]
        S4["fused_context"]
        S5["final_report"]
    end

    A -.->|escribe| S2
    B -.->|escribe| S3
    C -.->|lee S2+S3, escribe| S4
    D -.->|lee S4, escribe| S5
```

---

## Verification Plan

### Automated Tests
```bash
# 1. Verificar que la vectorstore se construye correctamente
python -c "from agentes import build_vectorstore; r = build_vectorstore('data_pdf'); print(f'Retriever OK: {r}')"

# 2. Ejecutar una consulta de prueba completa contra el grafo
python -c "from agentes import run_optiagent; result = run_optiagent('¿Qué es la aberración cromática?'); print(result['final_report'][:500])"

# 3. Verificar que Streamlit arranca sin errores
streamlit run App.py --server.headless true
```

### Manual Verification
- Probar con 3 preguntas de óptica de distinta complejidad:
  1. **Básica:** "¿Qué es la refracción de la luz?"
  2. **Intermedia:** "Explica la diferencia entre aberración esférica y cromática"
  3. **Avanzada:** "¿Cómo se aplica el interferómetro de Twyman-Green en el testing de superficies ópticas?"
- Validar que las fuentes citadas corresponden a los PDFs reales
- Confirmar que los resultados web complementan (no duplican) la información local
