import os
from pathlib import Path
from langchain_community.document_loaders import DirectoryLoader, PyPDFLoader
from langchain_experimental.text_splitter import SemanticChunker
from langchain_community.vectorstores import FAISS

# Importamos la fábrica de modelos para embeddings y la llave de Pinecone
from my_models import get_embeddings_model, EMBEDDING_MODELS_INFO
from my_keys import PINECONE_API_KEY

# Retriever global en memoria para evitar reconstrucciones innecesarias
_global_retriever = None
_last_provider = "Gemini"
_last_db_type = "FAISS"
_last_model_name = None

def build_vectorstore(pdf_dir: str = "data_pdf", provider: str = "Gemini", force_rebuild: bool = False, db_type: str = "FAISS", model_name: str = None):
    """
    Construye o carga el índice (FAISS o Pinecone) a partir de los PDFs locales.
    """
    global _global_retriever, _last_provider, _last_db_type, _last_model_name
    _last_provider = provider
    _last_db_type = db_type
    _last_model_name = model_name
    
    dir_path = Path(pdf_dir)
    
    # Obtenemos el modelo de embeddings
    embeddings_model = get_embeddings_model(provider, model_name)
    
    if db_type == "Pinecone":
        if not PINECONE_API_KEY:
            raise ValueError("Se requiere PINECONE_API_KEY en el archivo .env para usar Pinecone.")
        
        from pinecone import Pinecone, ServerlessSpec
        from langchain_pinecone import PineconeVectorStore
        
        pc = Pinecone(api_key=PINECONE_API_KEY)
        nombre_indice = f"optiagent-{provider.lower()}"
        
        if not model_name:
            model_name = list(EMBEDDING_MODELS_INFO[provider].keys())[0]
        dimension = EMBEDDING_MODELS_INFO[provider][model_name]
        
        # 1. Conectar a índice existente
        indices_existentes = [idx['name'] for idx in pc.list_indexes()]
        
        if nombre_indice in indices_existentes and not force_rebuild:
            print(f"[RAG Core] Conectando a índice existente en Pinecone: {nombre_indice}...")
            index_remoto = pc.Index(nombre_indice)
            stats = index_remoto.describe_index_stats()
            if stats.total_vector_count > 0:
                vectorstore = PineconeVectorStore(index=index_remoto, embedding=embeddings_model, pinecone_api_key=PINECONE_API_KEY)
                _global_retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
                print("[RAG Core] Vectorstore cargada exitosamente desde Pinecone.")
                return _global_retriever
            else:
                print(f"[RAG Core] El índice {nombre_indice} está vacío. Procediendo a reconstruir...")
                force_rebuild = True
        
        # Si no existe o se fuerza, lo recreamos
        if force_rebuild and nombre_indice in indices_existentes:
            print(f"[RAG Core] Borrando índice {nombre_indice} en Pinecone por force_rebuild...")
            pc.delete_index(nombre_indice)
            
        if nombre_indice not in [idx['name'] for idx in pc.list_indexes()]:
            print(f"[RAG Core] Creando nuevo índice {nombre_indice} en Pinecone (dim: {dimension})...")
            pc.create_index(
                name=nombre_indice,
                dimension=dimension,
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-east-1")
            )
            import time
            while not pc.describe_index(nombre_indice).status['ready']:
                time.sleep(1)
            
        index_remoto = pc.Index(nombre_indice)
        vectorstore = PineconeVectorStore(index=index_remoto, embedding=embeddings_model, pinecone_api_key=PINECONE_API_KEY)
        
    else:
        # Lógica original para FAISS
        index_path = Path(f"vectorstore/faiss_{provider.lower()}")
        
        if not force_rebuild and index_path.exists():
            print(f"[RAG Core] Cargando índice existente de {provider} desde disco ({index_path})...")
            try:
                vectorstore = FAISS.load_local(str(index_path), embeddings_model, allow_dangerous_deserialization=True)
                _global_retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
                print("[RAG Core] Vectorstore cargada exitosamente desde disco.")
                return _global_retriever
            except Exception as e:
                print(f"[RAG Core] Error al cargar índice local: {e}. Se procederá a reconstruir.")

    # 2. Si no se cargó un índice existente o se forzó reconstrucción, leemos los PDFs
    if not dir_path.exists():
        dir_path.mkdir(parents=True, exist_ok=True)
        return None

    print(f"[RAG Core] Cargando documentos desde {dir_path.absolute()}...")
    loader = DirectoryLoader(str(dir_path), glob="*.pdf", loader_cls=PyPDFLoader)
    docs = loader.load()

    if not docs:
        print("[RAG Core] No se encontraron PDFs en el directorio.")
        return None

    total_docs = len(docs)
    if total_docs > 100:
        print(f"[RAG Core] Aviso: Procesando max 100 páginas para ahorrar cuota.")
        docs = docs[:100]

    print(f"[RAG Core] Fragmentación Semántica ({provider}) para {len(docs)} páginas...")
    try:
        semantic_splitter = SemanticChunker(embeddings_model)
        chunks = semantic_splitter.split_documents(docs)
        print(f"[RAG Core] Se generaron {len(chunks)} chunks semánticos.")
    except Exception as e:
        print(f"[RAG Core] Falló SemanticChunker ({e}). Usando Recursive Splitter de respaldo...")
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split_documents(docs)
        print(f"[RAG Core] Se generaron {len(chunks)} chunks estándar.")

    print(f"[RAG Core] Vectorizando y construyendo {db_type} para {provider}...")
    
    try:
        if db_type == "Pinecone":
            vectorstore.add_documents(chunks)
        else:
            vectorstore = FAISS.from_documents(documents=chunks, embedding=embeddings_model)
            print(f"[RAG Core] Guardando índice en disco: {index_path}...")
            vectorstore.save_local(str(index_path))
    except Exception as e:
        if "RESOURCE_EXHAUSTED" in str(e) or "429" in str(e):
            raise RuntimeError("Cuota gratuita de la API de Embeddings excedida. Por favor, selecciona 'HuggingFace' como proveedor en el panel lateral.") from e
        raise e
    
    _global_retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
    print(f"[RAG Core] Vectorstore {db_type} lista y persistida.")
    return _global_retriever

def get_retriever():
    """
    Devuelve el retriever instanciado usando la última configuración conocida de la UI.
    Si no existe, intenta construirlo de forma perezosa.
    """
    global _global_retriever, _last_provider, _last_db_type, _last_model_name
    if _global_retriever is None:
        _global_retriever = build_vectorstore(
            provider=_last_provider,
            db_type=_last_db_type,
            model_name=_last_model_name
        )
    return _global_retriever
