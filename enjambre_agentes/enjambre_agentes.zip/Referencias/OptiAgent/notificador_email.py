import smtplib
from email.message import EmailMessage
from my_keys import EMAIL_SENDER, EMAIL_PASSWORD

def enviar_reporte_email(destinatario: str, asunto: str, contenido_markdown: str) -> bool:
    """
    Envía un correo electrónico utilizando el protocolo SMTP de Gmail.
    Retorna True si fue exitoso, False en caso de error.
    """
    if not EMAIL_SENDER or not EMAIL_PASSWORD:
        print("[Error] Credenciales de correo no configuradas en el entorno.")
        return False

    try:
        msg = EmailMessage()
        msg['Subject'] = asunto
        msg['From'] = EMAIL_SENDER
        msg['To'] = destinatario
        
        # Para evitar problemas con el renderizado, enviamos el markdown como texto plano estructurado.
        # En el futuro se podría usar la librería `markdown` para convertirlo a HTML si se desea.
        msg.set_content(f"Hola,\n\nAdjunto el reporte generado por OptiAgent:\n\n{'-'*50}\n\n{contenido_markdown}\n\n{'-'*50}\n\nSaludos,\nOptiAgent RAG System")

        # Conectar al servidor SMTP de Gmail (puerto 465 para SSL)
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(EMAIL_SENDER, EMAIL_PASSWORD)
            smtp.send_message(msg)
            
        print(f"[Notificador] Correo enviado exitosamente a {destinatario}")
        return True
    
    except Exception as e:
        print(f"[Notificador Error] Falló el envío de correo: {e}")
        return False
