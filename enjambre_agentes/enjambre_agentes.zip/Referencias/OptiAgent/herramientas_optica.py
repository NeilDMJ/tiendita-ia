import arxiv
import wikipedia
import requests
import sympy as sp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from sympy.parsing.sympy_parser import parse_expr
from langchain_core.tools import tool
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.tools.tavily_search import TavilySearchResults

from my_models import get_llm
from my_keys import TAVILY_API_KEY

@tool
def buscador_arxiv(query: str) -> str:
    """Busca artículos científicos puramente teóricos en arXiv y devuelve sus resúmenes y títulos. 
    Usa esta herramienta para investigar el estado del arte o teorías físicas profundas sobre óptica."""
    try:
        cliente = arxiv.Client()
        busqueda = arxiv.Search(
            query=query,
            max_results=3,
            sort_by=arxiv.SortCriterion.Relevance
        )
        resultados = []
        for paper in cliente.results(busqueda):
            resultados.append(
                f"Título: {paper.title}\n"
                f"Resumen: {paper.summary}\n"
                f"Enlace PDF: {paper.pdf_url}\n"
            )
        
        if not resultados:
            return "No se encontraron artículos teóricos para este tema en arXiv."
        
        return "\n---\n".join(resultados)
    except Exception as e:
        return f"Error consultando arXiv: {e}"

@tool
def traductor_didactico(concepto_complejo: str) -> str:
    """Utiliza esta herramienta cuando necesites 'traducir' un concepto óptico, matemático o muy técnico 
    a una explicación teórica, didáctica y fácil de entender usando analogías, sin perder el rigor."""
    
    llm = get_llm("Gemini")
    
    template = """Asume el papel de un profesor universitario experto en didáctica de la física.
    
    Se te ha pedido explicar el siguiente concepto óptico o físico encontrado durante una investigación:
    {concepto}
    
    Instrucciones:
    1. Elabora una explicación puramente teórica que sea de fácil comprensión para un estudiante universitario de primeros semestres.
    2. Evita demostraciones matemáticas densas; enfócate 100% en el significado y la intuición física.
    3. Utiliza analogías pedagógicas o ejemplos cotidianos para volver la explicación más sencilla.
    4. Mantén un alto rigor científico y precisión conceptual.
    """
    
    prompt = PromptTemplate(template=template, input_variables=["concepto"])
    cadena = prompt | llm | StrOutputParser()
    
    return cadena.invoke({"concepto": concepto_complejo})

@tool
def buscador_wikipedia(query: str) -> str:
    """Busca en Wikipedia información rápida, conceptos fundacionales, biografías de físicos o datos históricos. Usar para definiciones teóricas rápidas."""
    wikipedia.set_lang("es")
    try:
        resumen = wikipedia.summary(query, sentences=3)
        return resumen
    except wikipedia.exceptions.DisambiguationError as e:
        return f"El término es ambiguo. Opciones: {e.options[:5]}"
    except wikipedia.exceptions.PageError:
        return "No se encontró la página en Wikipedia."
    except Exception as e:
        return f"Error en Wikipedia: {e}"

@tool
def optimizador_ecuaciones(ecuacion_str: str) -> str:
    """Valida, simplifica matemáticamente y devuelve el código LaTeX estricto de una ecuación matemática o física. 
    OBLIGATORIO: La entrada debe ser un string en formato matemático de Python (ej: 'sin(x)**2 + cos(x)**2')."""
    try:
        expr = parse_expr(ecuacion_str)
        simplificada = sp.simplify(expr)
        latex_str = sp.latex(simplificada)
        return f"Ecuación validada y simplificada en formato LaTeX: $${latex_str}$$"
    except Exception as e:
        return f"Error procesando la ecuación: {e}. Asegúrate de usar sintaxis de Python para matemáticas."

@tool
def buscador_semantic_scholar(query: str) -> str:
    """Busca en la base de datos de Semantic Scholar. Ideal para cruzar la física óptica con otras ciencias (ej. medicina, ingeniería, biología). Devuelve títulos, autores y abstracts de artículos interdisciplinarios."""
    url = f"https://api.semanticscholar.org/graph/v1/paper/search?query={query}&limit=3&fields=title,authors,abstract,url"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if not data.get("data"):
                return "No se encontraron papers en Semantic Scholar para esta consulta."
            
            resultados = []
            for paper in data["data"]:
                autores = ", ".join([a["name"] for a in paper.get("authors", [])])
                titulo = paper.get("title", "")
                abstract = paper.get("abstract", "Sin abstract disponible.")
                url_paper = paper.get("url", "")
                resultados.append(f"Título: {titulo}\nAutores: {autores}\nResumen: {abstract}\nURL: {url_paper}\n")
            return "\n---\n".join(resultados)
        else:
            return f"Error HTTP {response.status_code} consultando Semantic Scholar."
    except Exception as e:
        return f"Error de red consultando Semantic Scholar: {e}"

@tool
def formateador_citas_ieee(autor: str, titulo: str, anio: str, url: str) -> str:
    """Recibe los metadatos crudos de un artículo o libro (autor, titulo, año, url) y devuelve la cita formateada estrictamente en norma IEEE, lista para incluirse en el reporte final."""
    cita = f"{autor}, \"{titulo},\" {anio}. [Online]. Disponible en: {url}"
    return f"Cita formateada (Norma IEEE):\n{cita}"

@tool
def buscador_patentes(query: str) -> str:
    """Busca exclusivamente patentes registradas sobre diseños e instrumentación óptica (ej. diseños de telescopios, láseres, lentes) usando los registros de Google Patents."""
    tavily = TavilySearchResults(max_results=3, tavily_api_key=TAVILY_API_KEY)
    # Forzamos la búsqueda solo en el dominio de patentes
    patente_query = f"site:patents.google.com {query}"
    try:
        resultados = tavily.invoke({"query": patente_query})
        text = ""
        for r in resultados:
            text += f"Patente (URL): {r.get('url')}\nExtracto: {r.get('content')}\n\n"
        if not text:
            return "No se encontraron patentes relacionadas con este tema."
        return text
    except Exception as e:
        return f"Error en la búsqueda de patentes: {e}"

@tool
def diccionario_optica(termino: str) -> str:
    """Obtiene la definición formal, ontológica y científicamente estricta de un término de física u óptica. Usa esta herramienta si desconoces o tienes dudas sobre el significado exacto de un término técnico."""
    llm = get_llm("Gemini")
    template = """Eres un diccionario oficial avalado por la Sociedad Óptica Internacional. 
    Define de forma concisa, formal y rigurosamente científica el siguiente término técnico:
    {termino}
    
    Proporciona ÚNICAMENTE la definición, sin saludos ni introducciones.
    """
    prompt = PromptTemplate(template=template, input_variables=["termino"])
    cadena = prompt | llm | StrOutputParser()
    return cadena.invoke({"termino": termino})

@tool
def lector_web_profundo(url: str) -> str:
    """Abre un navegador fantasma (headless) para extraer el texto completo de una página web o paper evadiendo bloqueos anti-bot.
    Usa esta herramienta cuando necesites leer TODO el contenido de una URL específica para responder adecuadamente."""
    if not url:
        return "Error: URL vacía proporcionada al scraper."
    
    try:
        opciones = webdriver.ChromeOptions()
        opciones.add_argument("--headless")
        opciones.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
        opciones.add_argument("--disable-gpu")
        opciones.add_argument("--no-sandbox")
        
        servicio = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=servicio, options=opciones)
        driver.set_page_load_timeout(30)
        
        driver.get(url)
        driver.implicitly_wait(10)
        html_crudo = driver.page_source
    except Exception as e:
        return f"Error al hacer scraping con Selenium: {e}"
    finally:
        if 'driver' in locals():
            driver.quit()
            
    sopa = BeautifulSoup(html_crudo, 'html.parser')
    for script in sopa(["script", "style", "noscript", "meta", "link", "header", "footer"]):
        script.decompose()
        
    texto = sopa.get_text(separator=' ', strip=True)
    return texto[:15000]
