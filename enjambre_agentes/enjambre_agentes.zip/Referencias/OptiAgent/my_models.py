import urllib.request
import json
import streamlit as st
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_huggingface import HuggingFaceEmbeddings
from my_keys import GEMINI_API_KEY, HF_TOKEN, COHERE_API_KEY, GROQ_API_KEY

# Constantes de modelos por si necesitas cambiarlos rápidamente
GEMINI_FLASH = "gemini-3.1-flash-lite"
GROQ_LLAMA3 = "llama-3.3-70b-versatile"
COHERE_COMMAND = "command-r7b-12-2024"

# Diccionario de modelos de embeddings y sus dimensiones
EMBEDDING_MODELS_INFO = {
    "Gemini": {
        "models/gemini-embedding-001": 768,
        "models/gemini-embedding-2-preview": 768,
        "models/gemini-embedding-2": 768
    },
    "HuggingFace": {
        "intfloat/multilingual-e5-small": 384,
        "sentence-transformers/all-MiniLM-L6-v2": 384,
        "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2": 384,
        "BAAI/bge-small-en-v1.5": 384,
        "BAAI/bge-m3": 1024,
        "sentence-transformers/all-mpnet-base-v2": 768,
        "sentence-transformers/multi-qa-MiniLM-L6-cos-v1": 384,
        "intfloat/multilingual-e5-base": 768,
        "avsolatorio/GIST-small-Embedding-v0": 384,
        "jinaai/jina-embeddings-v2-small-en": 512
    }
}

@st.cache_data(ttl=3600)
def get_available_llm_models(provider: str) -> list:
    """Obtiene dinámicamente la lista de modelos de la API, con fallback a constantes."""
    try:
        if provider == "Gemini" and GEMINI_API_KEY:
            url = f"https://generativelanguage.googleapis.com/v1beta/models?key={GEMINI_API_KEY}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                return [m['name'].replace('models/', '') for m in data.get("models", []) 
                        if "generateContent" in m.get("supportedGenerationMethods", [])]
                        
        elif provider == "Cohere" and COHERE_API_KEY:
            req = urllib.request.Request('https://api.cohere.ai/v1/models', 
                                         headers={'Authorization': f'Bearer {COHERE_API_KEY}'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                return [m['name'] for m in data.get('models', []) if 'chat' in m.get('endpoints', [])]
                
        elif provider == "Groq" and GROQ_API_KEY:
            req = urllib.request.Request('https://api.groq.com/openai/v1/models', 
                                         headers={'Authorization': f'Bearer {GROQ_API_KEY}'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                return [m['id'] for m in data.get('data', [])]
    except Exception as e:
        print(f"Error cargando modelos de {provider}: {e}")
        
    # Fallbacks de seguridad si la API falla o falta la llave
    if provider == "Gemini":
        return [GEMINI_FLASH, "gemini-1.5-pro", "gemini-1.5-flash"]
    elif provider == "Cohere":
        return [COHERE_COMMAND, "command-r-plus"]
    elif provider == "Groq":
        return [GROQ_LLAMA3, "llama-3.1-8b-instant", "mixtral-8x7b-32768"]
    return []

def get_llm(provider: str, model_name: str = None):
    """Fábrica de LLMs dinámicos según el proveedor."""
    if provider == "Groq":
        from langchain_groq import ChatGroq
        final_model = model_name if model_name else GROQ_LLAMA3
        return ChatGroq(model=final_model, temperature=0.2)
    elif provider == "Cohere":
        from langchain_cohere import ChatCohere
        final_model = model_name if model_name else COHERE_COMMAND
        return ChatCohere(model=final_model, temperature=0.2)
    else:
        # Por defecto Gemini
        from langchain_google_genai import ChatGoogleGenerativeAI
        if not GEMINI_API_KEY:
            raise ValueError("Se requiere GEMINI_API_KEY en .env para usar el LLM de Gemini.")
        final_model = model_name if model_name else GEMINI_FLASH
        return ChatGoogleGenerativeAI(model=final_model, temperature=0.2, api_key=GEMINI_API_KEY)

def get_embeddings_model(provider: str, model_name: str = None):
    """
    Fábrica de modelos de embeddings.
    Si no se provee model_name, se elige el primero del proveedor por defecto.
    """
    if not model_name:
        model_name = list(EMBEDDING_MODELS_INFO[provider].keys())[0]
        
    if provider == "HuggingFace":
        if not HF_TOKEN:
            raise ValueError("Se requiere HF_TOKEN en .env para usar Hugging Face Embeddings.")
        return HuggingFaceEmbeddings(
            model_name=model_name
        )
    else:
        # Por defecto Gemini
        if not GEMINI_API_KEY:
            raise ValueError("Se requiere GEMINI_API_KEY en .env para generar los embeddings del FAISS.")
        return GoogleGenerativeAIEmbeddings(model=model_name, google_api_key=GEMINI_API_KEY)
