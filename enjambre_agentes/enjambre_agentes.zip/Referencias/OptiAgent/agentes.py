import os
import warnings
from typing import List, TypedDict, Dict, Annotated
from operator import add
from pydantic import BaseModel, Field
import re

# Utilidades LangChain y LangGraph
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_community.tools.tavily_search import TavilySearchResults
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver

# Importar configuración y modelos modulares
from my_keys import TAVILY_API_KEY
from my_models import get_llm
from herramientas_optica import (
    buscador_arxiv,
    traductor_didactico,
    buscador_wikipedia,
    optimizador_ecuaciones,
    buscador_semantic_scholar,
    formateador_citas_ieee,
    buscador_patentes,
    diccionario_optica,
    lector_web_profundo
)
from rag_core import get_retriever

# --- 1. CONFIGURACIÓN ---
if not TAVILY_API_KEY:
    raise ValueError("Se requiere TAVILY_API_KEY en .env")

# Herramientas
tavily_tool = TavilySearchResults(max_results=3, tavily_api_key=TAVILY_API_KEY)


# --- 2. ESTADO DEL AGENTE (MEMORIA COMPARTIDA) ---
class OptiAgentState(TypedDict):
    messages: Annotated[list, add]  # Historial de conversación mantenido por LangGraph
    query: str
    provider: str
    llm_model_name: str
    flow_type: str  # "Solo Web", "Solo Local", "Híbrido"
    response_mode: str  # "Resumen", "Extensa"
    rag_context: str
    web_tavily_results: str
    web_academic_results: str
    web_scraper_results: str
    web_context: str
    fused_context: str
    final_report: str
    sources_local: List[str]
    sources_web: List[str]


# --- 3. PYDANTIC SCHEMAS ---
class SearchQueries(BaseModel):
    queries: List[str] = Field(description="Lista de consultas de búsqueda web enfocadas y académicas")


# --- 4. NODOS DEL GRAFO ---

def rag_analyzer_node(state: OptiAgentState):
    """Agente A: Recupera contexto de los PDFs científicos locales mediante rag_core."""
    print("\n[Agente A - RAG] Buscando en documentos locales...")
    query = state["query"]
    
    retriever = get_retriever()
    if retriever is None:
        return {"rag_context": "No se encontraron documentos locales indexados.", "sources_local": []}
    
    docs = retriever.invoke(query)
    
    context = ""
    sources = set()
    for doc in docs:
        context += f"{doc.page_content}\n\n"
        source_name = doc.metadata.get('source', 'Documento desconocido')
        page_num = doc.metadata.get('page', 'N/A')
        sources.add(f"{Path(source_name).name if 'Path' in globals() else os.path.basename(source_name)} (Pág. {page_num})")
        
    return {
        "rag_context": context.strip() if context else "No se encontró información relevante en los documentos locales.",
        "sources_local": list(sources)
    }

def web_dispatch_node(state: OptiAgentState):
    """Nodo Fork: Despacha la consulta a los miniagentes web en paralelo."""
    print("[Dispatcher Web] Iniciando miniagentes de búsqueda en paralelo...")
    return {}

def web_tavily_node(state: OptiAgentState):
    """Miniagente: Búsqueda Web General."""
    print(f"[Miniagente Tavily] Buscando contexto general con {state['provider']}...")
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    agente = create_react_agent(
        model=llm,
        tools=[tavily_tool, buscador_wikipedia, diccionario_optica, traductor_didactico, formateador_citas_ieee],
        prompt="Eres un agente especializado en búsquedas generales rápidas. Encuentra información introductoria y devuelve un resumen. SIEMPRE incluye las URLs usadas, y de preferencia extrae la cita formal (IEEE/APA) usando formateador_citas_ieee."
    )
    resultado = agente.invoke({"messages": state.get("messages", []) + [("user", state["query"])]})
    return {"web_tavily_results": resultado["messages"][-1].content}

def web_academic_node(state: OptiAgentState):
    """Miniagente: Búsqueda Académica."""
    print(f"[Miniagente Académico] Buscando papers y patentes con {state['provider']}...")
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    agente = create_react_agent(
        model=llm,
        tools=[buscador_arxiv, buscador_semantic_scholar, buscador_patentes, optimizador_ecuaciones, formateador_citas_ieee],
        prompt="Eres un agente especializado en literatura académica profunda. Encuentra papers, patentes o artículos científicos. OBLIGATORIAMENTE incluye las URLs o DOIs de tus fuentes y usa formateador_citas_ieee para estructurarlas."
    )
    resultado = agente.invoke({"messages": state.get("messages", []) + [("user", state["query"])]})
    return {"web_academic_results": resultado["messages"][-1].content}

def web_scraper_node(state: OptiAgentState):
    """Miniagente: Búsqueda y Scraping Profundo."""
    print(f"[Miniagente Scraper] Buscando y scrapeando webs con {state['provider']}...")
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    agente = create_react_agent(
        model=llm,
        tools=[tavily_tool, lector_web_profundo, formateador_citas_ieee],
        prompt="Eres un agente especializado en extracción profunda de artículos. Usa tavily_search_results_json para encontrar enlaces, y OBLIGATORIAMENTE usa lector_web_profundo para extraer el contenido completo. Tienes autorización y prioridad para buscar o navegar en estos repositorios del INAOE usando lector_web_profundo si la consulta está relacionada: 'https://inaoe.repositorioinstitucional.mx/jspui/handle/1009/5', 'https://speckle.inaoep.mx/publicaciones/2014', y especialmente 'https://inaoe.repositorioinstitucional.mx/jspui/handle/1009/5/browse?type=author&order=ASC&rpp=20&value=FERMIN+SALOMON+GRANADOS+AGUSTIN'. Resume lo encontrado detalladamente, asegurándote de incluir la URL exacta y generar su cita formal con formateador_citas_ieee."
    )
    resultado = agente.invoke({"messages": state.get("messages", []) + [("user", state["query"])]})
    return {"web_scraper_results": resultado["messages"][-1].content}

def web_parser_node(state: OptiAgentState):
    """Agente Parseador: Consolida todos los resultados web."""
    print(f"[Agente Parseador] Sintetizando la investigación web de todos los miniagentes...")
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    prompt = """Eres el Agente Parseador Jefe.
Han llegado los reportes de tus 3 miniagentes investigadores.
Tu tarea es fusionar esta información en un solo contexto estructurado.
Organiza la información por fuentes, URLs y contenido clave.
No dejes fuera ninguna URL aportada por los miniagentes.

AL FINAL DE TU REPORTE, OBLIGATORIAMENTE debes incluir un bloque de etiquetas XML <sources>...</sources> con la lista de todas las fuentes y URLs que usaron los miniagentes, una por línea.
Ejemplo:
<sources>
- URL 1 (Formato IEEE/APA)
- URL 2 (Formato IEEE/APA)
</sources>

Consulta Original: {query}

--- REPORTE TAVILY (General) ---
{tavily}

--- REPORTE ACADÉMICO ---
{academic}

--- REPORTE SCRAPER ---
{scraper}
"""
    messages = [
        SystemMessage(content="Actúa como un sintetizador web maestro."),
        HumanMessage(content=prompt.format(
            query=state['query'],
            tavily=state.get('web_tavily_results', 'Sin datos'),
            academic=state.get('web_academic_results', 'Sin datos'),
            scraper=state.get('web_scraper_results', 'Sin datos')
        ))
    ]
    response = llm.invoke(messages)
    
    if isinstance(response.content, list):
        text = "".join([b.get('text', '') if isinstance(b, dict) else str(b) for b in response.content])
    else:
        text = str(response.content)
        
    sources_web = []    
    match = re.search(r"<sources>(.*?)</sources>", text, re.DOTALL | re.IGNORECASE)
    if match:
        sources_raw = match.group(1).strip().split('\n')
        sources_web = [s.strip("- ") for s in sources_raw if s.strip()]
        text = re.sub(r"<sources>.*?</sources>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
        
    if not sources_web:
        sources_web = ["No se detectaron URLs en los reportes de los miniagentes."]
        
    return {
        "web_context": text,
        "sources_web": sources_web
    }

def fusion_node(state: OptiAgentState):
    """Agente C: Fusiona y reconcilia fuentes locales y web."""
    print(f"[Agente C - Fusionador] Sintetizando contexto con {state['provider']}...")
    
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    
    prompt = """Eres un experto científico sintetizador en óptica.
Tu tarea es analizar dos fuentes de información (Local RAG y Web Search) para la consulta actual del usuario, teniendo en cuenta el historial si es relevante.
1. Identifica complementariedades.
2. Detecta divergencias o discrepancias.
3. Unifica la terminología técnica al español.
4. Redacta un contexto fusionado unificado y estructurado etiquetando la información clave con [LOCAL] o [WEB] según su procedencia.

Consulta: {query}

--- CONTEXTO LOCAL (PDFs) ---
{rag_context}

--- CONTEXTO WEB (ReAct Agent) ---
{web_context}
"""
    messages = [
        SystemMessage(content="Actúa como un sintetizador científico preciso."),
        HumanMessage(content=prompt.format(
            query=state['query'], 
            rag_context=state['rag_context'], 
            web_context=state['web_context']
        ))
    ]
    
    response = llm.invoke(messages)
    return {"fused_context": response.content}

def summary_writer_node(state: OptiAgentState):
    """Agente D1: Redacta un resumen de 1 oración."""
    print(f"[Agente D1 - Resumen] Escribiendo reporte corto con {state['provider']}...")
    
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    
    local_src = "\n- ".join(state.get('sources_local', []))
    web_src = "\n- ".join(state.get('sources_web', []))
    flow = state.get("flow_type", "Híbrido")
    
    if flow == "Solo Local":
        context_text = state.get('rag_context', '')
    elif flow == "Solo Web":
        context_text = state.get('web_context', '')
    else:
        context_text = state.get('fused_context', '')
        
    prompt = """Eres un Agente experto en sintetizar conocimiento.
Tu tarea es hacer un resumen ULTRA-CORTO de la información proporcionada.
NO añadas comentarios adicionales ni frases de cortesía. 

REGLAS ESTRICTAS:
1. Analiza el contexto y responde directamente.
2. La respuesta debe ser corta, breve y concisa: de a lo mucho UNA SOLA ORACIÓN.
3. Devuelve SOLO el resumen en TEXTO PURO absoluto (sin formato Markdown, nada de *, # o _).
4. NO incluyas las fuentes ni herramientas en tu texto final, el Agente Parseador ya las recolectó por separado.

Consulta actual: {query}

--- CONTENIDO EXTRAÍDO (raw_content) ---
{context_text}
"""
    messages = [
        SystemMessage(content="Eres un sintetizador ultra-conciso."),
        HumanMessage(content=prompt.format(
            query=state['query'],
            context_text=context_text
        ))
    ]
    
    response = llm.invoke(messages)
    
    if isinstance(response.content, list):
        final_text = "".join([b.get('text', '') if isinstance(b, dict) else str(b) for b in response.content])
    else:
        final_text = str(response.content)
        
    return {
        "final_report": final_text,
        "messages": [AIMessage(content=final_text)]
    }

def scientific_writer_node(state: OptiAgentState):
    """Agente D2: Redacta un artículo científico estructurado."""
    print(f"[Agente D2 - Científico] Escribiendo artículo con {state['provider']}...")
    
    llm = get_llm(state['provider'], state.get('llm_model_name'))
    
    local_src = "\n- ".join(state.get('sources_local', []))
    web_src = "\n- ".join(state.get('sources_web', []))
    flow = state.get("flow_type", "Híbrido")
    
    if flow == "Solo Local":
        context_text = state.get('rag_context', '')
    elif flow == "Solo Web":
        context_text = state.get('web_context', '')
    else:
        context_text = state.get('fused_context', '')
        
    prompt = """Eres un Doctor en Óptica e Investigador Científico Experto.
Tu tarea es redactar un artículo científico divulgativo basado en la información extraída.

REGLAS ESTRICTAS:
1. Usa lenguaje formal, técnico y objetivo.
2. Estructura obligatoria del artículo usando Markdown:
   - **Introducción**: Contexto de la consulta.
   - **Desarrollo**: Explicación detallada de los conceptos o el problema.
   - **Conclusión**: Hallazgos clave o resumen técnico.
3. NO incluyas bibliografía al final, el UI se encargará de mostrar las fuentes recolectadas.

Consulta actual: {query}

--- CONTENIDO EXTRAÍDO (raw_content) ---
{context_text}
"""
    messages = [
        SystemMessage(content="Eres un Doctor en Óptica e Investigador altamente calificado."),
        HumanMessage(content=prompt.format(
            query=state['query'],
            context_text=context_text
        ))
    ]
    
    response = llm.invoke(messages)
    
    if isinstance(response.content, list):
        final_text = "".join([b.get('text', '') if isinstance(b, dict) else str(b) for b in response.content])
    else:
        final_text = str(response.content)
        
    return {
        "final_report": final_text,
        "messages": [AIMessage(content=final_text)]
    }

# --- 5. RUTEO Y CONSTRUCCIÓN DEL GRAFO CON MEMORIA ---

def router_start(state: OptiAgentState):
    flow = state.get("flow_type", "Híbrido")
    if flow == "Solo Web":
        return "Flujo: Solo Web"
    return "Flujo: Analizar PDFs"

def router_writer(state: OptiAgentState):
    """Enruta al nodo correspondiente según el modo de respuesta elegido."""
    mode = state.get("response_mode", "Modo Resumen")
    if mode == "Modo Científico":
        return "Escribir: Científico"
    return "Escribir: Resumen"

builder = StateGraph(OptiAgentState)

builder.add_node("rag_analyzer", rag_analyzer_node)
builder.add_node("web_dispatch", web_dispatch_node)
builder.add_node("web_tavily", web_tavily_node)
builder.add_node("web_academic", web_academic_node)
builder.add_node("web_scraper", web_scraper_node)
builder.add_node("web_parser", web_parser_node)
builder.add_node("fusion", fusion_node)
builder.add_node("summary_writer", summary_writer_node)
builder.add_node("scientific_writer", scientific_writer_node)

builder.add_conditional_edges(START, router_start, {
    "Flujo: Solo Web": "web_dispatch",
    "Flujo: Analizar PDFs": "rag_analyzer"
})

# Router para RAG: si es "Solo Local", vamos directo a redactores. Si no, a la web.
def router_rag_mod(state: OptiAgentState):
    flow = state.get("flow_type", "Híbrido")
    if flow == "Solo Local":
        return router_writer(state)
    return "Flujo: Híbrido (Ir a Web)"

builder.add_conditional_edges("rag_analyzer", router_rag_mod, {
    "Escribir: Resumen": "summary_writer",
    "Escribir: Científico": "scientific_writer",
    "Flujo: Híbrido (Ir a Web)": "web_dispatch"
})

# Distribución paralela
builder.add_edge("web_dispatch", "web_tavily")
builder.add_edge("web_dispatch", "web_academic")
builder.add_edge("web_dispatch", "web_scraper")

# Convergencia
builder.add_edge("web_tavily", "web_parser")
builder.add_edge("web_academic", "web_parser")
builder.add_edge("web_scraper", "web_parser")

# Router para Web: si es "Solo Web", vamos a redactores. Si no, a fusión.
def router_web_mod(state: OptiAgentState):
    flow = state.get("flow_type", "Híbrido")
    if flow == "Solo Web":
        return router_writer(state)
    return "Flujo: Híbrido (Fusionar)"

builder.add_conditional_edges("web_parser", router_web_mod, {
    "Escribir: Resumen": "summary_writer",
    "Escribir: Científico": "scientific_writer",
    "Flujo: Híbrido (Fusionar)": "fusion"
})

# Fusión siempre va a los redactores
builder.add_conditional_edges("fusion", router_writer, {
    "Escribir: Resumen": "summary_writer",
    "Escribir: Científico": "scientific_writer"
})

builder.add_edge("summary_writer", END)
builder.add_edge("scientific_writer", END)

# Inyectar MemorySaver para historial
memory = MemorySaver()
opti_graph = builder.compile(checkpointer=memory)

# --- 6. EXPORTACIÓN PARA LA UI ---
def run_optiagent_stream(query: str, thread_id: str, provider: str = "Gemini", llm_model_name: str = None, flow_type: str = "Híbrido", response_mode: str = "Resumen"):
    """Ejecuta el grafo multiagente con historial (MemorySaver) y realiza stream para la interfaz."""
    initial_state = {
        "messages": [HumanMessage(content=query)], # Se suma a los existentes
        "query": query,
        "provider": provider,
        "llm_model_name": llm_model_name,
        "flow_type": flow_type,
        "response_mode": response_mode,
        "rag_context": "",
        "web_tavily_results": "",
        "web_academic_results": "",
        "web_scraper_results": "",
        "web_context": "",
        "fused_context": "",
        "final_report": "",
        "sources_local": [],
        "sources_web": []
    }
    
    # Configuramos el hilo de memoria (thread_id)
    config = {"configurable": {"thread_id": thread_id}}
    
    for event in opti_graph.stream(initial_state, config=config):
        yield event
