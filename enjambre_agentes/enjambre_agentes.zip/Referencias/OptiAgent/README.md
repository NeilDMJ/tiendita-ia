# OptiAgent-RAG: Sistema Multiagente Inteligente para Investigación en Óptica

OptiAgent-RAG es una aplicación de Inteligencia Artificial especializada en óptica. Orquesta un flujo multiagente que procesa documentación en PDFs locales y consultas a la web en tiempo real, cruzando la información para generar reportes técnicos de alto rigor académico.

## ✨ Características y Capacidades (Novedades)
- **Arquitectura Modular RAG:** Usa `FAISS` en memoria y *Semantic Chunking* (división semántica de texto) para extraer la información más relevante de tus documentos PDF de manera precisa.
- **Arsenal Científico Completo:** Integración nativa con herramientas como `arXiv`, `PubMed` y `Wikipedia` para dotar al agente de conocimiento teórico profundo.
- **Scraping Profundo (Anti-Evasión):** Cuenta con un "navegador fantasma" basado en **Selenium y BeautifulSoup** que le permite al agente evadir bloqueos 403 de servidores web y extraer contenido directo cuando el resumen de búsqueda general es insuficiente.
- **Memoria Persistente:** Usa `MemorySaver` de LangGraph acoplado al ID de sesión de Streamlit para recordar todo el contexto de la conversación (historial de chat real).
- **Flexibilidad Multi-Modelo:** Preparado para ejecutar flujos de razonamiento usando los mejores modelos disponibles en **Google Gemini**, **Groq** o **Cohere** mediante un selector dinámico en la interfaz.
- **Exportación SMTP:** Incluye la capacidad de enviar el reporte final limpiamente maquetado a cualquier dirección de correo electrónico real utilizando un módulo de notificaciones nativo en Python.
- **Interfaz Interactiva:** Despliega el grafo de ejecución (StateGraph) renderizado en Mermaid, muestra las fuentes exactas con enlaces interactivos en menús desplegables y contiene una barra lateral para afinar el flujo de ejecución.

## 🏗️ Arquitectura Multiagente Avanzada

El sistema opera mediante un grafo de ejecución (StateGraph) orquestado con **LangGraph**, compuesto por múltiples nodos especialistas y enrutadores condicionales:

### 1. Agente A (Analizador RAG Local)
Se encarga de buscar en la base documental privada (PDFs). Soporta índices locales con **FAISS** y bases de datos vectoriales en la nube con **Pinecone**, usando fragmentación semántica (*Semantic Chunking*) para máxima precisión. Permite usar motores de embeddings locales (HuggingFace) o en la nube (Gemini).

### 2. Escuadrón de Búsqueda Web (Agente B y Miniagentes)
La búsqueda externa se ejecuta de forma **paralela** desplegando 3 miniagentes especialistas, seguidos de un coordinador:
- **Miniagente Académico:** Interroga bases de datos como arXiv, PubMed y Wikipedia para sustento teórico.
- **Miniagente Scraper:** Visita repositorios institucionales (ej. INAOE) y extrae artículos científicos evadiendo bloqueos web usando BeautifulSoup.
- **Miniagente Tavily:** Realiza búsquedas de contexto general en la web en tiempo real.
- **Agente Parseador Jefe:** Sintetiza los hallazgos de los 3 miniagentes anteriores, estructura el conocimiento y extrae meticulosamente las URLs para garantizar la correcta citación.

### 3. Agente C (Fusionador y Resolución de Conflictos)
Cruza la información recuperada por el Agente A (PDFs locales) con la investigación del Escuadrón Web. Si detecta contradicciones entre los documentos y la web, evalúa las fuentes y genera un contexto purificado unificado.

### 4. Enrutamiento y Agentes Redactores (Agentes D)
Dependiendo del "Estilo de Redacción" seleccionado por el usuario en la interfaz, un enrutador inteligente (Router) dirige el flujo hacia uno de dos escritores especialistas:
- **Agente D1 (Redactor de Resumen):** Sintetiza la respuesta en un formato ultra-corto y conciso, ideal para lecturas rápidas.
- **Agente D2 (Investigador Científico):** Adopta el rol de "Doctor en Óptica". Estructura la información como un artículo formal (Introducción, Desarrollo Teórico, Conclusión) y elabora citas rigurosas en formato IEEE/APA.

## 🚀 Guía de Instalación y Ejecución

### 1. Clonar y preparar entorno
```bash
# Entrar al directorio
cd OptiAgent

# Crear un ENTORNO VIRTUAL LIMPIO (Recomendado para evitar conflictos de dependencias)
python -m venv venv
source venv/bin/activate  # En Linux/Mac
# venv\Scripts\activate   # En Windows

# Instalar dependencias
pip install -r requirements.txt
```

### 2. Configurar Variables de Entorno
Copia el archivo de ejemplo (o crea un `.env`) y agrega tus credenciales:
```env
GEMINI_API_KEY="tu_clave_de_gemini"
TAVILY_API_KEY="tu_clave_de_tavily"
GROQ_API_KEY="tu_clave_de_groq"
COHERE_API_KEY="tu_clave_de_cohere"

# Vector Store en la nube (obligatorio para persistencia)
PINECONE_API_KEY="tu_clave_de_pinecone"

# Configuración para envío de reportes
EMAIL_SENDER="tu_correo@gmail.com"
EMAIL_PASSWORD="tu_contraseña_de_aplicacion"
```

### 3. Agregar Datos (PDFs)
Asegúrate de colocar los documentos PDF que desees indexar dentro de la carpeta `data_pdf/`.

### 4. Ejecutar la Aplicación
Lanza la interfaz web usando Streamlit:
```bash
streamlit run App.py
```
Abre tu navegador en la URL indicada (generalmente `http://localhost:8501`).

## 💡 Ejemplos Prácticos de Preguntas

Puedes probar el sistema con estas consultas de diferente nivel de complejidad:

1. **Básico:** "¿Qué es la aberración esférica y cómo se corrige en los telescopios?"
2. **Intermedio:** "Explica el funcionamiento y los beneficios de usar el interferómetro de Twyman-Green frente al interferómetro de Fizeau."
3. **Avanzado:** "Genera un informe sobre los métodos matemáticos y físicos aplicados en el Optical Shop Testing para medir superficies asféricas, citando las teorías base."

## ☁️ Despliegue en la Nube (Streamlit Community Cloud)

OptiAgent-RAG está listo para ser desplegado de manera gratuita en **Streamlit Community Cloud**. Sigue estos pasos:

1. **Sube tu código a GitHub** (Asegúrate de NO subir tu archivo `.env`).
2. En la raíz de tu repositorio ya se incluye un archivo llamado `packages.txt` con el contenido:
   ```text
   chromium
   chromium-driver
   ```
   *Esto es vital para que el servidor de Streamlit instale los controladores del navegador oculto para el Agente Scraper (Selenium).*
3. Vincula tu repositorio en [share.streamlit.io](https://share.streamlit.io/).
4. Antes de darle a **"Deploy"**, ve a la sección de **Advanced settings** > **Secrets** y pega el contenido exacto de tu archivo `.env`.
5. ¡Listo! Tu escuadrón de agentes ya está disponible públicamente en la nube.
